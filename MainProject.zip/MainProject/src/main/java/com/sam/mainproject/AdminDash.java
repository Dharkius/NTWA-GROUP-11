package com.sam.mainproject;

    import javafx.event.ActionEvent;
    import javafx.fxml.FXML;
    import javafx.scene.Node;
    import javafx.scene.Scene;
    import javafx.scene.control.Button;
    import javafx.fxml.FXMLLoader;
    import javafx.scene.Parent;
    import javafx.scene.control.TextField;
    import javafx.stage.Stage;

    import java.io.IOException;

public class AdminDash {

    @FXML
    private Button btnaddstud;

    @FXML
    private Button btnaddteach;

    @FXML
    private Button btndelstud;

    @FXML
    private Button btndelteach;

    @FXML
    private Button btnlogout;

    @FXML
    private Button btnviewresult;

    private Stage stage;
    private Scene scene;
    private Parent root;

    public void btnaddstud(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("AddStudent.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Addtion Of Student");
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void btnaddteach(ActionEvent event) throws IOException {
    root = FXMLLoader.load(getClass().getResource("AddTeacher.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Addtion Of Teachers");
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void btndelstud(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("DeleteStudent.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Deletion Of Student");
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void btndelteach(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("DeleteTeacher.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Deletion Of Teachers");
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void btnlogout(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void btnviewresult(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("ViewResult.fxml"));
        stage.setTitle("View Results");
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
   }


}
