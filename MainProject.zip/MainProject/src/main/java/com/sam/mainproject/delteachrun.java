package com.sam.mainproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import javafx.stage.Stage;
public class delteachrun extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("DeleteTeacher.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600.0, 270.0);
        Stage stage = new Stage();
        stage.setTitle("Deletion Of Teacher!");
        stage.setScene(scene);
        stage.show();
    }





}
