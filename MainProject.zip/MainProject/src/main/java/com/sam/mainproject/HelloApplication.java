package com.sam.mainproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
   //rivate Stage stage;
   //rivate Scene scene;
   //rivate Parent root;

    private static Stage stg;
    @Override
    public void start(Stage stage) throws IOException {
        stg = stage;
        //stage .setResizable(false);
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),601.0, 432.0);
        stage.setTitle("LOGIN PAGE!");
        stage.setScene(scene);
        stage.show();
    }
    //public  void changeScene(String fxml) throws IOException{
       // Parent root = FXMLLoader.load(getClass().get)
        //stg = FXMLLoader.load(getClass().getResource(fxml));
        //stg = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //scene = new Scene(root);
        //stg.getScene();
        //stg.show();
  //  }
    public static void main(String[] args) {launch();
    }
}