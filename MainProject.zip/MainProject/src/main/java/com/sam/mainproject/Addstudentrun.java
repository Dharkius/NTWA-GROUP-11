package com.sam.mainproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Addstudentrun extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception{

        Parent root = FXMLLoader.load(getClass().getResource("AddStudent.fxml"));
        Scene scene = new Scene(root, 534.0, 317.0);
        primaryStage.setTitle("Addition of Student");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

