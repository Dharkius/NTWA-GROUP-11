package com.sam.mainproject;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class TeacherEnter {
    @FXML
    private Button btncalculate;
    @FXML
    private Button btnexit;
    @FXML
    private Button btnupdate;
    @FXML
    private TextField tfclastest;
    @FXML
    private TextField tfclaswork;
    @FXML
    private TextField tfcourse;
    @FXML
    private TextField tfexams;
    @FXML
    private TextField tffulname;
    @FXML
    private TextField tfgrade;
    @FXML
    private TextField tfhomework;
    @FXML
    private TextField tfmidexams;
    @FXML
    private TextField tfstudentid;
    @FXML
    private TextField tfsubject;
    @FXML
    private TextField tftotal;


    @FXML
    void btncalculate(ActionEvent event) throws IOException {
        //Double studentid, midexams, grade, homework, exams, claswork, clastest;
      //  Double total = null;
       // String subject, fulname, course;

        try {
           double studentid = Double.parseDouble((tfstudentid.getText()));
            double midexams = Double.parseDouble((tfmidexams.getText()));
            double grade = Double.parseDouble(tfgrade.getText());
            double homework = Double.parseDouble(tfhomework.getText());
            double exams = Double.parseDouble(tfexams.getText());
            double clastest = Double.parseDouble(tfclastest.getText());
            double claswork = Double.parseDouble(tfclaswork.getText());
           double  total = Double.parseDouble(tftotal.getText());

           String subject = tfsubject.getText();
           String fulname = tffulname.getText();
           String course = tfcourse.getText();

           total = exams+ midexams+ homework+ clastest+ claswork;
           tftotal.setText(String.valueOf(total));

        if (total >= 85 && total < 100) {
            tfgrade.setText("A");
        }
        else if (total >= 75 && total < 85) {
            tfgrade.setText("B");
        }
        else if (total >= 65 && total < 75) {
            tfgrade.setText("C");
        }
        else if (total >= 50 && total < 65) {
            tfgrade.setText("D");
        }
        else if (total > 50) {
            tfgrade.setText("Failed");
        }

        } catch (Exception e) {
            System.out.println(e);
        }

    }

}