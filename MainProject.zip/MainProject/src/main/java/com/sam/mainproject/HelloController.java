package com.sam.mainproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.fxml.FXML;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {

        @FXML
        private MenuItem btnadmin;

        @FXML
        private Button btnlogin;

        @FXML
        private MenuItem btnteacher;
        @FXML
        private Label wrongLogIn;
        @FXML
        private PasswordField tfpassword;
        @FXML
        private TextField tfusername;

    private Stage stage;
    private Scene scene;
    private Parent root;

   // public void Btnadmin(ActionEvent event) throws IOException {


    public void btnlogin(ActionEvent event) throws IOException {
        //checklogin();

        //root = FXMLLoader.load(getClass().getResource("AdminDash.fxml"));
        //stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //scene = new Scene(root);
        //stage.setScene(scene);
        //stage.show();}
        HelloApplication a = new HelloApplication();
        if (tfusername.getText().toString().equals("Admin") && tfpassword.getText().toString().equals("Myadmin123")) {
            wrongLogIn.setText("Success!");
            Parent root = FXMLLoader.load(getClass().getResource("AdminDash.fxml"));
            Stage window = (Stage) btnlogin.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();
        }
        else if (tfusername.getText().isEmpty() && tfpassword.getText().isEmpty()){
            wrongLogIn.setText("Please Enter Date");
        }
        else if (tfusername.getText().toString().equals("Teacher") && tfpassword.getText().toString().equals("Myteacher123")) {
            wrongLogIn.setText("Success!");
            Parent root = FXMLLoader.load(getClass().getResource("TeacherEnter.fxml"));
            Stage window = (Stage) btnlogin.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();
        }
        else if (tfusername.getText().isEmpty() && tfpassword.getText().isEmpty()){
            wrongLogIn.setText("Please Fill In the Blank");
        }
        if (tfusername.getText().toString().equals("Student") && tfpassword.getText().toString().equals("Mystudent123")) {
            wrongLogIn.setText("Success!");
            Parent root = FXMLLoader.load(getClass().getResource("StudentViewResult.fxml"));
            Stage window = (Stage) btnlogin.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();
        }
        else if (tfusername.getText().isEmpty() && tfpassword.getText().isEmpty()){
            wrongLogIn.setText("Please Enter Date");
        }
        else {
            wrongLogIn.setText("Wrong Username & Password");
        }
    }
    //@FXML
    //void btnlogin(ActionEvent event) throws Exception {
       // String username = tfusername.getText();
        //String password = tfpassword.getText();
        //if (new Dbacess().


          //      log(username, password) == 0) {
            //Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            //alert.setContentText("Login Successful");
            //alert.setHeaderText(null);
            //alert.showAndWait();

            //tfusername.clear();
            //tfpassword.clear();

            //Stage stage = (Stage) btnlogin.getScene().getWindow();
            //Parent root = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
            //Scene scene = new Scene(root);
            //stage.setTitle("Grading System");
            //stage.setScene(scene);
            //stage.show();

        //} else {
          //  Alert alert = new Alert(Alert.AlertType.ERROR);
            //alert.setContentText("Wrong Username or Password, Retype!!!");
            //alert.setHeaderText(null);
            //alert.showAndWait();
        //}


}