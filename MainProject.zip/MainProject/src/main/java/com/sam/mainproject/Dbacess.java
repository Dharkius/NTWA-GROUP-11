package com.sam.mainproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;

//public class Dbacess {

  //      private final String Driver = "com.mysql.cj.jdbc.Driver";
    //    private final String DatabaseName = "GradingSystem";
      //  private final String DatabaseUser = "root";
        //private final String DatabasePassword = "";
        //private final String url = "jdbc:mysql://" + DatabaseUser + ":" + DatabasePassword + "@" + "localhost/" + DatabaseName;

        //public Dbacess() throws Exception {
          //  Class.forName(Driver);
            //connection = DriverManager.getConnection(url);
        //}

        //Connection connection = null;
        //PreparedStatement preparedStatement = null;
        //ResultSet resultSet = null;

        //Main Page login database
    //public int log(String username, String password) throws SQLException {
      //  preparedStatement = connection.prepareStatement("SELECT * FROM `Login` WHERE username = 'Admin' and password = 'Myadmin123'; ");
        //preparedStatement.setString(1, username);
       // preparedStatement.setString(2, password);
        //ResultSet resultSet = preparedStatement.executeQuery();
        //if
        //(resultSet.next()) {
          //  return 0;
        //} else {
          //  return 0;
        //}
    //}

    //}
