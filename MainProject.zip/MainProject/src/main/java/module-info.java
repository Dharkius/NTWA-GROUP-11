module com.sam.mainproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;

    opens com.sam.mainproject to javafx.fxml;
    exports com.sam.mainproject;
}